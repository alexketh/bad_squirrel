package com.mycompany.a3.Interfaces;

//IStrategy Interface
public interface IStrategy {

	public void apply();
	//public void setStrategy();
	//public void invokeStrategy();

}
