package com.mycompany.a3.Interfaces;

//IIterator interface
public interface IIterator {

	public boolean hasNext();
	public Object getNext();

}
