package com.mycompany.a3.Interfaces;

public interface ICollection {

	public void add (Object object);
	public IIterator getIterator();

}
