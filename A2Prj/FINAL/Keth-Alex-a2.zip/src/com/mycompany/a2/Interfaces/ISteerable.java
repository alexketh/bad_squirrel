package com.mycompany.a2.Interfaces;

public interface ISteerable {
	public void steerLeft();
	public void steerRight();
}
