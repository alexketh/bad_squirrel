package com.mycompany.a2.Interfaces;

//IStrategy Interface
public interface IStrategy {
	
	public void apply();
	//public void setStrategy();
	//public void invokeStrategy();
	
}