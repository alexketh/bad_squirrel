package com.mycompany.a2.Interfaces;

//IIterator interface
public interface IIterator {
	
	public boolean hasNext();
	public Object getNext();
	
}